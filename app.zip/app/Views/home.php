<?= $this->extend('template/admin') ?>

<?= $this->section('content') ?>
Hai
<?= $this->endSection() ?>